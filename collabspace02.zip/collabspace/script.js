/* Collabspace – demo logic.
   Sign-in is Google (Firebase Auth) and all shared data lives in Firestore (see firebase-auth.js and
   firestore.rules). `db` is an in-memory mirror kept live by Firestore listeners; save() writes only
   what changed. */

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid = () => Math.random().toString(36).slice(2, 10);

const emptyDb = () => ({ users:{}, mail:[], meetings:[], projects:[], chats:{} });
let db = emptyDb();
let me = null, secret = null;                                  // secret = { email, skey } of the signed-in user (private doc)
let view = 'home', openProj = null, openChat = null, meetProj = null, meetMode = 'list', homeSel = null, homeY = 0, homeM = 0, focusNext = false, editMeet = null;

/* ---------- Firestore sync ----------
   users/{name}  meetings/{id}  mail/{id}  projects/{id}  chats/{key}  (+ secrets/{uid}, private)
   Extra "uid" fields are added on write so firestore.rules can tell who may read a document. */
const enc = s => encodeURIComponent(s).replace(/\./g, '%2E');
const STAMPS = ['fromUid', 'toUid', 'ownerUid', 'memberUids', 'uids'];
const clean = o => JSON.parse(JSON.stringify(o));
const canon = v => Array.isArray(v) ? '[' + v.map(canon).join(',') + ']'
  : v && typeof v === 'object' ? '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + canon(v[k])).join(',') + '}' : JSON.stringify(v);
const uidOf = n => db.users[n]?.uid;
const uidsOf = names => [...new Set((names || []).map(uidOf).filter(Boolean))];
function chatUids(key) {
  if (key.startsWith('p:')) return uidsOf(db.projects.find(p => p.id === key.slice(2))?.members);
  return uidsOf(key.split('|'));
}
let parts = {}, synced = new Map(), chatLen = new Map(), watcher = null;

function stopSync() { watcher?.stop(); watcher = null; parts = {}; synced = new Map(); chatLen = new Map(); db = emptyDb(); secret = null; }

// Called by firebase-auth.js for every Firestore snapshot.
window.cwApplyRemote = (src, docs, local) => {
  parts[src] = docs;
  if (local) return;                                         // echo of our own write: db already has it
  const users = {}, chats = {}, maps = { mail:new Map(), meetings:new Map(), projects:new Map() };
  synced = new Map(); chatLen = new Map();
  for (const [s, list] of Object.entries(parts)) {
    const col = s.split(':')[0];
    for (const { id, data } of list) {
      synced.set(col + '/' + id, canon(clean(data)));
      if (col === 'users') { const { name, ...u } = data; users[name] = u; }
      else if (col === 'chats') { chats[data.key] = data.msgs || []; chatLen.set(id, (data.msgs || []).length); synced.set('chats/' + id, canon(clean({ key:data.key, uids:data.uids, msgs:data.msgs || [] }))); }
      else { const item = { ...data }; STAMPS.forEach(k => delete item[k]); maps[col].set(id, item); }
    }
  }
  const byAge = (a, b) => (a.cAt || 0) - (b.cAt || 0);
  db = { users, chats, mail:[...maps.mail.values()].sort(byAge), meetings:[...maps.meetings.values()].sort(byAge), projects:[...maps.projects.values()].sort(byAge) };
  if (me && db.users[me]) render(false);
};

function stamped(col, item) {
  if (col === 'mail') return { ...item, fromUid:uidOf(item.from), toUid:uidOf(item.to) };
  if (col === 'meetings') return { ...item, ownerUid:uidOf(item.owner), memberUids:uidsOf([item.owner, ...(item.members || [])]) };
  if (col === 'projects') return { ...item, memberUids:uidsOf(item.members) };
  return item;
}

function save() {
  const ops = [], seen = new Set();
  const put = (col, id, data) => {
    const k = col + '/' + id; seen.add(k); data = clean(data); const c = canon(data);
    if (synced.get(k) !== c) { ops.push({ t:'set', col, id, data }); synced.set(k, c); }
  };
  Object.entries(db.users).forEach(([name, u]) => put('users', enc(name), { name, ...u }));
  ['mail', 'meetings', 'projects'].forEach(col => db[col].forEach(item => { item.cAt ||= Date.now(); put(col, item.id, stamped(col, item)); }));
  Object.entries(db.chats).forEach(([key, msgs]) => {
    const id = enc(key), k = 'chats/' + id; seen.add(k);
    const data = clean({ key, uids:chatUids(key) }), c = canon({ ...data, msgs:clean(msgs) });
    if (synced.get(k) !== c) {
      const prev = chatLen.get(id) || 0;
      ops.push({ t:'chat', id, data, add:clean(msgs.slice(prev)) });
      synced.set(k, c); chatLen.set(id, msgs.length);
    }
  });
  for (const k of [...synced.keys()]) if (!seen.has(k)) { const [col, ...rest] = k.split('/'); ops.push({ t:'del', col, id:rest.join('/') }); synced.delete(k); chatLen.delete(k.slice(6)); }
  if (!ops.length || !window.cwStore) return Promise.resolve();
  const p = window.cwStore.commit(ops);
  p.catch(err => { console.error(err); toast('Could not save to the cloud (' + (err.code || err.message) + ')'); });
  return p;
}
const load = () => db;

const TITLES = { home:'Home', find:'Find a collaborator', meet:'Meetings', proj:'Work on project', collab:'Collaborators', port:'Portfolio', mail:'Mail', chat:'Chat', settings:'Settings' };
const VIEWS = ['home','find','meet','proj','collab','port','mail','chat','settings'];
/* ---------- Small helpers: icons, toast, pointer spotlight ---------- */
const PHONE = '<span class="phone" title="Meeting invitation"><svg viewBox="0 0 24 24"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/></svg></span>';
const BAG = '<span class="phone bag" title="Project invitation"><svg viewBox="0 0 24 24"><path d="M5 8h14l-1 12H6zM9 8V6a3 3 0 0 1 6 0v2"/></svg></span>';
function toast(t) { const d = document.createElement('div'); d.className = 'toast'; d.setAttribute('role', 'status'); d.textContent = t; document.body.append(d); setTimeout(() => d.remove(), 3300); }
document.addEventListener('pointermove', e => {
  const c = e.target.closest?.('.card,.panel,.meet,.mail,.homemeet'); if (!c) return;
  const r = c.getBoundingClientRect(); c.style.setProperty('--mx', e.clientX - r.left + 'px'); c.style.setProperty('--my', e.clientY - r.top + 'px');
});

const user = n => db.users[n];
const collabs = () => user(me).collabs;
const dmKey = (a, b) => [a, b].sort().join('|');
const initial = n => esc(n[0].toUpperCase());
const fmtTime = d => { let h = d.getHours(), m = d.getMinutes(), ap = h >= 12 ? 'pm' : 'am'; h = h % 12 || 12; return `${h}.${String(m).padStart(2,'0')} ${ap}`; };
const fmtDate = d => d.toLocaleDateString(undefined, { weekday:'short', day:'numeric', month:'short' });
function parseTime(t) {
  const m = t.trim().match(/^(\d{1,2})[.:](\d{2})\s*(am|pm)$/i); if (!m) return null;
  let h = +m[1] % 12; if (m[3].toLowerCase() === 'pm') h += 12;
  return (+m[1] > 12 || +m[2] > 59) ? null : [h, +m[2]];
}

/* ---------- SKEY: stored only as a salted SHA-256 hash ---------- */
const sha = async s => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)))].map(b => b.toString(16).padStart(2, '0')).join('');
const hashKey = (k, email) => sha('cw1:' + email + ':' + k);
const isKey = k => /^\d{4}$/.test(k);
document.addEventListener('input', e => { if (e.target.matches('#aKey,#aKey2,#skeyInput,#stNew,#stNew2')) e.target.value = e.target.value.replace(/\D/g, ''); });

let skeyDone = null, skeyTries = 0, skeyLock = 0;
function askSkey(why) {                                     // resolves true only when the right SKEY was typed
  return new Promise(res => {
    $('#skeyWhy').textContent = why; $('#skeyInput').value = ''; $('#skeyMsg').textContent = '';
    $('#skeyModal').hidden = false; $('#skeyInput').focus(); skeyDone = res;
  });
}
function closeSkey(ok) { $('#skeyModal').hidden = true; const r = skeyDone; skeyDone = null; if (r) r(ok); }
$('#skeyCancel').onclick = () => closeSkey(false);
$('#skeyModal').addEventListener('pointerdown', e => { if (e.target === $('#skeyModal')) closeSkey(false); });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && skeyDone) closeSkey(false); });
$('#skeyForm').onsubmit = async e => {
  e.preventDefault(); const msg = $('#skeyMsg');
  if (Date.now() < skeyLock) { msg.textContent = `Too many tries. Wait ${Math.ceil((skeyLock - Date.now()) / 1000)}s.`; return; }
  if (secret && isKey($('#skeyInput').value) && await hashKey($('#skeyInput').value, secret.email) === secret.skey) { skeyTries = 0; closeSkey(true); return; }
  if (++skeyTries >= 5) { skeyLock = Date.now() + 30000; skeyTries = 0; }
  msg.textContent = 'Wrong SKEY. Try again.'; $('#skeyInput').select();
};

/* ---------- Sign in with Google (firebase-auth.js calls cwOnUser) ---------- */
let gUser = null;
const bootTimer = setTimeout(() => { if (!me) { showAuth(); $('#authMsg').textContent = 'Could not reach Firebase. Serve this page over http(s) and check your connection.'; } }, 6000);

window.cwOnUser = async fb => {
  clearTimeout(bootTimer); gUser = fb; stopSync();
  if (!fb) return showAuth();
  try {
    watcher = window.cwStore.watch(fb.uid, window.cwApplyRemote);
    await watcher.ready;                                      // users, mail, meetings, projects, chats loaded
    secret = await window.cwStore.getSecret(fb.uid);
  } catch (err) {
    showAuth(); $('#authMsg').textContent = 'Could not load your data (' + (err.code || err.message || 'unknown') + '). Check the Firestore rules and your connection.'; return;
  }
  const handle = Object.keys(db.users).find(n => db.users[n].uid === fb.uid);
  if (handle) { me = handle; enterApp(); } else showSetup(fb);
};
function showAuth() {
  me = null;
  closePicker(); closeProfile();
  $('#app').hidden = true; $('#auth').hidden = false;
  $('#gStep').hidden = false; $('#setupStep').hidden = true; $('#authMsg').textContent = '';
}
function showSetup(fb) {
  $('#app').hidden = true; $('#auth').hidden = false;
  $('#gStep').hidden = true; $('#setupStep').hidden = false; $('#authMsg').textContent = '';
  $('#aName').value = (fb.displayName || '').slice(0, 24); $('#aInfo').focus();
}
function enterApp() {
  $('#auth').hidden = true; $('#app').hidden = false;
  $('#who').textContent = me + ' ✎';
  view = 'home'; openProj = openChat = meetProj = editMeet = null; meetMode = 'list'; homeSel = null;
  picked.clear();
  setView(view);
}
$('#gBtn').onclick = async () => {
  $('#authMsg').textContent = '';
  try { await window.cwAuth.signIn(); }
  catch (err) { $('#authMsg').textContent = 'Google sign-in failed (' + (err.code || err.message || 'unknown') + ').'; }
};
$('#authForm').onsubmit = async e => {
  e.preventDefault(); const msg = $('#authMsg');
  if (!gUser || $('#setupStep').hidden) return;
  const name = $('#aName').value.trim(), info = $('#aInfo').value.trim(), k = $('#aKey').value, email = gUser.email.toLowerCase();
  if (name.length < 2 || !info) { msg.textContent = 'Enter your name and an Info Line.'; return; }
  if (!isKey(k)) { msg.textContent = 'SKEY must be exactly 4 digits.'; return; }
  if (k !== $('#aKey2').value) { msg.textContent = 'The two SKEYs do not match.'; return; }
  if (db.users[name] && db.users[name].uid !== gUser.uid) { msg.textContent = 'That name is taken. Pick another.'; return; }
  db.users[name] = { info, skills:'', about:'', links:'', collabs:[], uid:gUser.uid };
  secret = { email, skey: await hashKey(k, email) };
  try { await window.cwStore.setSecret(gUser.uid, secret); await save(); }
  catch (err) { delete db.users[name]; secret = null; msg.textContent = 'Could not create the account (' + (err.code || err.message) + '). The name may be taken.'; return; }
  me = name; e.target.reset(); enterApp();
};
$('#logout').onclick = () => { if (window.cwAuth) window.cwAuth.signOut(); showAuth(); };

/* ---------- Edit profile (Info Line) ---------- */
function openProfile() {
  if (!me || !user(me)) return;
  $('#prName').value = me; $('#prInfo').value = user(me).info;
  $('#modal').hidden = false;
  $('#prInfo').focus(); $('#prInfo').select();
}
function closeProfile() {
  if ($('#modal').hidden) return;
  $('#modal').hidden = true;
  $('#who').focus();
}
$('#who').onclick = openProfile;
$('#prCancel').onclick = closeProfile;
$('#modal').addEventListener('pointerdown', e => { if (e.target === $('#modal')) closeProfile(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeProfile(); });
$('#profForm').onsubmit = e => {
  e.preventDefault();
  db = load();
  const info = $('#prInfo').value.trim(); if (!info) return;
  user(me).info = info; save();
  if (view === 'port') $('#poInfo').value = info;
  closeProfile(); toast('Info Line updated'); render();
};

/* ---------- 3D mesh on the sign-in screen (drag to rotate) ---------- */
(function mesh() {
  const cv = $('#mesh'), ctx = cv.getContext('2d');
  const norm = v => { const l = Math.hypot(...v); return v.map(x => x / l); };
  const clamp = x => Math.max(0, Math.min(1, x));

  // Icosahedron, subdivided once -> a geodesic sphere of 42 points
  const t = (1 + Math.sqrt(5)) / 2;
  const V = [[-1,t,0],[1,t,0],[-1,-t,0],[1,-t,0],[0,-1,t],[0,1,t],[0,-1,-t],[0,1,-t],[t,0,-1],[t,0,1],[-t,0,-1],[-t,0,1]].map(norm);
  const F = [[0,11,5],[0,5,1],[0,1,7],[0,7,10],[0,10,11],[1,5,9],[5,11,4],[11,10,2],[10,7,6],[7,1,8],
             [3,9,4],[3,4,2],[3,2,6],[3,6,8],[3,8,9],[4,9,5],[2,4,11],[6,2,10],[8,6,7],[9,8,1]];
  const cache = {}, tri = [];
  const mid = (a, b) => {
    const k = a < b ? a + '_' + b : b + '_' + a;
    if (cache[k] === undefined) { V.push(norm(V[a].map((x, i) => x + V[b][i]))); cache[k] = V.length - 1; }
    return cache[k];
  };
  F.forEach(([a, b, c]) => { const ab = mid(a, b), bc = mid(b, c), ca = mid(c, a); tri.push([a,ab,ca], [b,bc,ab], [c,ca,bc], [ab,bc,ca]); });
  const E = new Set();
  tri.forEach(f => f.forEach((a, i) => { const b = f[(i + 1) % 3]; E.add(a < b ? a + '_' + b : b + '_' + a); }));
  const edges = [...E].map(k => k.split('_').map(Number));

  let rx = .5, ry = 0, vx = 0, vy = 0, drag = false, lx = 0, ly = 0, w = 0, h = 0, dpr = 1;
  const still = matchMedia('(prefers-reduced-motion:reduce)').matches;

  function size() { dpr = window.devicePixelRatio || 1; w = cv.clientWidth; h = cv.clientHeight; cv.width = w * dpr; cv.height = h * dpr; }
  new ResizeObserver(size).observe(cv);

  function draw(ts) {
    const time = ts / 1000, s = Math.min(w, h) * .36, cx = w / 2, cy = h / 2;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
    const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, s * 1.6);
    g.addColorStop(0, 'rgba(139,156,255,.20)'); g.addColorStop(1, 'rgba(139,156,255,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);

    const cY = Math.cos(ry), sY = Math.sin(ry), cX = Math.cos(rx), sX = Math.sin(rx);
    const P = V.map(([x, y, z]) => {
      const k = 1 + .09 * Math.sin(x * 3 + time * 1.2) * Math.cos(y * 3 - time * .9);   // gentle breathing
      x *= k; y *= k; z *= k;
      const x1 = x * cY + z * sY, z1 = -x * sY + z * cY;
      const y2 = y * cX - z1 * sX, z2 = y * sX + z1 * cX;
      const f = 3.2 / (3.2 - z2);
      return [cx + x1 * s * f, cy + y2 * s * f, z2];
    });
    ctx.lineWidth = 1;
    edges.forEach(([a, b]) => {
      const A = P[a], B = P[b], d = clamp(((A[2] + B[2]) / 2 + 1.1) / 2.2);
      ctx.strokeStyle = `hsla(${235 - 65 * d},90%,${65 + 10 * d}%,${.1 + .65 * d})`;
      ctx.beginPath(); ctx.moveTo(A[0], A[1]); ctx.lineTo(B[0], B[1]); ctx.stroke();
    });
    P.forEach(([x, y, z]) => {
      const d = clamp((z + 1.1) / 2.2);
      ctx.fillStyle = `hsla(${235 - 65 * d},95%,${70 + 10 * d}%,${.25 + .75 * d})`;
      ctx.beginPath(); ctx.arc(x, y, 1 + 2.2 * d, 0, 7); ctx.fill();
    });
  }
  function frame(ts) {
    requestAnimationFrame(frame);
    if ($('#auth').hidden || !w) return;
    if (!drag) { rx += vx; ry += vy + (still ? 0 : .004); vx *= .94; vy *= .94; }   // inertia + slow idle spin
    draw(ts);
  }
  requestAnimationFrame(frame);

  cv.addEventListener('pointerdown', e => { drag = true; lx = e.clientX; ly = e.clientY; cv.setPointerCapture(e.pointerId); });
  cv.addEventListener('pointermove', e => {
    if (!drag) return;
    const dx = e.clientX - lx, dy = e.clientY - ly; lx = e.clientX; ly = e.clientY;
    ry += dx * .01; rx += dy * .01; vy = dx * .01; vx = dy * .01;
  });
  const up = () => { drag = false; };
  cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
})();

/* ---------- Auto-delete: a meeting is removed from history 20 minutes after its scheduled start ---------- */
const MEET_TTL = 20 * 60 * 1000;
function purgeMeetings() {
  const fresh = load(), now = Date.now(), gone = new Set(fresh.meetings.filter(m => m.ts + MEET_TTL <= now).map(m => m.id));
  if (!gone.size) return false;
  fresh.meetings = fresh.meetings.filter(m => !gone.has(m.id));
  fresh.mail = fresh.mail.filter(m => !(m.type === 'meeting' && gone.has(m.ref)));   // their invitation mails go too
  db = fresh; save(); return true;
}
purgeMeetings();

/* ---------- Navigation ---------- */
const nav = $('#nav');
function setView(v) {
  view = v;
  if (v !== 'meet') closePicker();                           // the picker belongs to the meeting form
  $$('#nav nav button').forEach(b => b.classList.toggle('on', b.dataset.view === v));
  VIEWS.forEach(x => $('#v-' + x).hidden = x !== v);
  $('#title').textContent = TITLES[v];
  render(true);
}
$$('#nav nav button').forEach(b => b.onclick = () => {
  if (b.dataset.view === 'proj') openProj = null;
  if (b.dataset.view === 'meet') { meetMode = 'list'; meetProj = null; editMeet = null; }
  setView(b.dataset.view);
  // collapse the menu after a selection; it re-opens on the next hover
  nav.classList.add('shut');
  if (document.activeElement) document.activeElement.blur();
});
nav.addEventListener('mouseleave', () => nav.classList.remove('shut'));
document.addEventListener('pointerdown', e => { if (!nav.contains(e.target)) nav.classList.remove('shut'); });

setInterval(() => { if (me && user(me)) { purgeMeetings(); renderMeetList(); if (view === 'home') renderHome(); else if (view === 'mail') renderMail(); } }, 15000);

function render(fresh) {
  if (!me || !user(me)) return;
  purgeMeetings();
  const pending = db.mail.filter(m => m.to === me && m.status === 'pending').length;
  $('#mailCount').hidden = !pending; $('#mailCount').textContent = pending;
  ({ home:renderHome, find:renderFind, meet:()=>renderMeet(fresh), proj:()=>renderProj(fresh), collab:renderCollab, port:()=>renderPort(fresh), mail:renderMail, chat:renderChat, settings:()=>renderSettings(fresh) })[view](); badges();
}

/* ---------- Invite helpers ---------- */
const inviteSent = n => db.mail.some(m => m.type === 'invite' && m.from === me && m.to === n && m.status === 'pending');
const inviteReceived = n => db.mail.some(m => m.type === 'invite' && m.from === n && m.to === me && m.status === 'pending');
// Mutuals = invite sent by one side and accepted by the other (both lists hold each other)
const isMutual = n => !!user(n) && collabs().includes(n) && user(n).collabs.includes(me);

/* ---------- Home: clock · recent chats + Highlights · calendar ---------- */
function updateClock() {
  const d = new Date(), h = d.getHours() % 12 || 12;
  $('#clockTime').textContent = `${h}:${pad(d.getMinutes())}`;
  $('#clockSec').textContent = `${pad(d.getSeconds())} ${d.getHours() >= 12 ? 'PM' : 'AM'}`;
  $('.ring').style.setProperty('--p', d.getSeconds() / 60);
  $('#clockDate').innerHTML = `${d.toLocaleDateString(undefined, { weekday:'long' })}<br>${d.toLocaleDateString(undefined, { day:'numeric', month:'short', year:'numeric' })}`;
}
setInterval(() => { if (view === 'home' && me) updateClock(); }, 1000);

const joinUrl = l => { l = String(l || '').trim(); return /^[a-z][a-z0-9+.-]*:\/\//i.test(l) ? l : 'https://' + l; };

function renderHome() {
  updateClock();
  const now = new Date(), today = keyOf(now);
  if (!homeSel) { homeSel = today; homeY = now.getFullYear(); homeM = now.getMonth(); }
  const mine = db.meetings.filter(m => m.accepted.includes(me)), marks = new Set(mine.map(m => keyOf(new Date(m.ts))));
  const first = new Date(homeY, homeM, 1), days = new Date(homeY, homeM + 1, 0).getDate();
  $('#hLabel').textContent = first.toLocaleDateString(undefined, { month:'long', year:'numeric' });
  let h = ['S','M','T','W','T','F','S'].map(d => `<span class="wd">${d}</span>`).join('') + '<span></span>'.repeat(first.getDay());
  for (let d = 1; d <= days; d++) {
    const k = `${homeY}-${pad(homeM + 1)}-${pad(d)}`;
    h += `<button type="button" class="day${k === homeSel ? ' sel' : ''}${k === today ? ' today' : ''}${marks.has(k) ? ' has' : ''}" data-hday="${k}" aria-label="${fmtDate(fromKey(k))}">${d}</button>`;
  }
  $('#hGrid').innerHTML = h; $('#hPick').textContent = fmtDate(fromKey(homeSel));
  const list = mine.filter(m => keyOf(new Date(m.ts)) === homeSel).sort((a, b) => a.ts - b.ts);
  $('#hMeets').innerHTML = list.map(m => `<div class="homemeet ${m.ts < Date.now() - 36e5 ? 'over' : ''}"><div class="info"><b>${PHONE}${esc(m.purpose)}</b><span class="line">${esc(m.timeLabel)} &middot; ${esc(m.members.join(', ') || 'just you')}</span></div><button class="btn" data-join="${m.id}">Join</button></div>`).join('')
    || '<p class="dim">No meetings on this day.</p>';
  $('#homeRecent').innerHTML = recentKeys().slice(0, 10).map(k => chatRow(k, 'data-homechat', false)).join('')
    || '<p class="dim">No chats yet. Message a mutual collaborator to get started.</p>';
  const stat = [[collabs().filter(isMutual).length, 'Mutuals'], [mine.filter(m => keyOf(new Date(m.ts)) === today).length, 'Meetings today'], [mine.filter(m => m.ts > Date.now()).length, 'Upcoming']];
  $('#homeStats').innerHTML = stat.map(([n, l]) => `<div><b>${n}</b><span>${l}</span></div>`).join('');
  $('#homeHigh').innerHTML = db.mail.filter(m => m.to === me && m.type === 'update' && m.status === 'pending').sort((a, b) => b.ts - a.ts).slice(0, 6)
    .map(m => `<div class="hl"><div>${PHONE}<b>${esc(m.title)}</b> <span class="dim">from ${esc(m.from)}, ${stamp(m.ts)}</span><br><span class="dim">${m.changes.map(esc).join('<br>')}</span></div><button class="ghost sm" data-seen="${m.id}">OK</button></div>`).join('')
    || '<p class="dim">No changes to your meetings.</p>';
}
$('#hPrev').onclick = () => { homeM--; if (homeM < 0) { homeM = 11; homeY--; } renderHome(); };
$('#hNext').onclick = () => { homeM++; if (homeM > 11) { homeM = 0; homeY++; } renderHome(); };
$('#hToday').onclick = () => { homeSel = null; renderHome(); };
document.addEventListener('click', e => {
  const d = e.target.closest('[data-hday]'); if (d) { homeSel = d.dataset.hday; renderHome(); }
  const j = e.target.closest('[data-join]');                  // Join opens the meeting link straight away
  if (j) { const m = db.meetings.find(x => x.id === j.dataset.join); if (m && m.accepted.includes(me)) window.open(joinUrl(m.link), '_blank', 'noopener'); }
  const c = e.target.closest('[data-homechat]');
  if (c && canChat(c.dataset.homechat)) { openChat = c.dataset.homechat; focusNext = true; setView('chat'); }
});

/* ---------- Find a collaborator ---------- */
function renderFind() {
  const others = Object.keys(db.users).filter(n => n !== me);
  $('#findList').innerHTML = others.map(n => {
    const u = user(n), isC = collabs().includes(n), sent = inviteSent(n);
    return `<div class="card"><div class="avatar">${initial(n)}</div>
      <div class="info"><b>${esc(n)}</b><span class="line">${esc(u.info)}</span></div>
      <button class="btn" data-invite="${esc(n)}" ${isC || sent ? 'disabled' : ''}>${isC ? 'Collaborator' : sent ? 'Invited' : 'Invite'}</button></div>`;
  }).join('') || '<p class="dim">No other users yet. Open another tab and sign in with a different Google account.</p>';
}
document.addEventListener('click', e => {
  const t = e.target.closest('[data-invite]'); if (!t || t.disabled) return;
  const n = t.dataset.invite;
  if (!collabs().includes(n) && !inviteSent(n))
    db.mail.push({ id:uid(), type:'invite', from:me, to:n, status:'pending', ts:Date.now() });
  save(); render();
});

/* ---------- Mail (invites and meeting changes land here) ---------- */
function renderMail() {
  const list = db.mail.filter(m => m.to === me).sort((a, b) => b.ts - a.ts);
  $('#mailList').innerHTML = list.map(m => {
    let text;
    if (m.type === 'invite') text = `<b>${esc(m.from)}</b> invited you to collaborate.`;
    else if (m.type === 'project') { const p = db.projects.find(x => x.id === m.ref); text = p ? `${BAG}<b>${esc(m.from)}</b> invited you to join the project <b>${esc(p.name)}</b>` : 'Project was removed.'; }
    else if (m.type === 'update') text = `${PHONE}<b>${esc(m.from)}</b> changed the meeting <b>${esc(m.title)}</b><br><span class="dim">${m.changes.map(esc).join('<br>')}</span>`;
    else { const mt = db.meetings.find(x => x.id === m.ref); text = mt ? `${PHONE}<b>${esc(m.from)}</b> invited you to <b>${esc(mt.purpose)}</b><br><span class="dim">${fmtDate(new Date(mt.ts))}, ${esc(mt.timeLabel)}</span>` : 'Meeting was removed.'; }
    const acts = m.status !== 'pending' ? `<span class="dim">${m.status}</span>`
      : m.type === 'update' ? `<div class="acts"><button class="btn" data-seen="${m.id}">OK</button></div>`
      : `<div class="acts"><button class="ghost" data-decline="${m.id}">Decline</button><button class="btn ok" data-accept="${m.id}">Accept</button></div>`;
    return `<div class="mail ${m.status !== 'pending' ? 'done' : ''}"><div>${text}</div>${acts}</div>`;
  }).join('') || '<p class="dim">Your mailbox is empty.</p>';
}
document.addEventListener('click', async e => {
  const a = e.target.closest('[data-accept]'), d = e.target.closest('[data-decline]'), s = e.target.closest('[data-seen]');
  if (s) { const m = db.mail.find(x => x.id === s.dataset.seen); if (m && m.to === me) { m.status = 'seen'; save(); render(); } }
  if (d) { db.mail.find(m => m.id === d.dataset.decline).status = 'declined'; save(); render(); }
  if (a) {
    if (!(await askSkey('Enter your SKEY to accept this invitation.'))) return;
    db = load(); const m = db.mail.find(x => x.id === a.dataset.accept); if (!m || m.status !== 'pending') return;
    m.status = 'accepted';
    if (m.type === 'invite') { [[me, m.from], [m.from, me]].forEach(([x, y]) => { if (user(x) && !user(x).collabs.includes(y)) user(x).collabs.push(y); }); }
    else if (m.type === 'project') {
      const p = db.projects.find(x => x.id === m.ref);
      if (p && !p.members.includes(me)) { p.members.push(me); (db.chats['p:' + p.id] ||= []).push({ from:'system', ts:Date.now(), text:`${me} joined the project.` }); }
    } else { const mt = db.meetings.find(x => x.id === m.ref); if (mt && !mt.accepted.includes(me)) mt.accepted.push(me); }
    save(); render();
  }
});

/* ---------- Checkbox helper (used by the project form; keeps ticks while re-rendering) ----------
   Lists every collaborator, plus people with a pending request (shown greyed out
   until the request is accepted). */
function fillChecks(el) {
  const on = new Set($$(`#${el} input:checked`).map(i => i.value));
  const ok = collabs();
  const pend = Object.keys(db.users).filter(n => n !== me && !ok.includes(n) && (inviteSent(n) || inviteReceived(n)));
  const html = ok.map(n => `<label><input type="checkbox" value="${esc(n)}" ${on.has(n) ? 'checked' : ''}>${esc(n)}</label>`)
    .concat(pend.map(n => `<label class="pending" title="Request not accepted yet"><input type="checkbox" disabled>${esc(n)} <em>(pending)</em></label>`));
  $('#' + el).innerHTML = html.join('') || '<span class="dim">No collaborators yet — send a request from Find a collaborator.</span>';
}
const checked = el => $$(`#${el} input:checked`).map(i => i.value);

/* ---------- Meeting calendar ---------- */
const pad = n => String(n).padStart(2, '0');
const keyOf = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const fromKey = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
let calSel = null, calY = 0, calM = 0;
function selectDate(key) { calSel = key; const d = fromKey(key); calY = d.getFullYear(); calM = d.getMonth(); }

function renderCal() {
  const now = new Date(), today = keyOf(now);
  if (!calSel) selectDate(today);
  const first = new Date(calY, calM, 1), lead = first.getDay(), days = new Date(calY, calM + 1, 0).getDate();
  $('#calLabel').textContent = first.toLocaleDateString(undefined, { month:'long', year:'numeric' });
  $('#calPrev').disabled = calY === now.getFullYear() && calM <= now.getMonth();
  let html = ['S','M','T','W','T','F','S'].map(d => `<span class="wd">${d}</span>`).join('') + '<span></span>'.repeat(lead);
  for (let d = 1; d <= days; d++) {
    const k = `${calY}-${pad(calM + 1)}-${pad(d)}`;
    html += `<button type="button" class="day${k === calSel ? ' sel' : ''}${k === today ? ' today' : ''}" data-day="${k}" ${k < today ? 'disabled' : ''} aria-label="${fmtDate(fromKey(k))}" aria-pressed="${k === calSel}">${d}</button>`;
  }
  $('#calGrid').innerHTML = html;
  $('#calPick').textContent = fmtDate(fromKey(calSel));
}
$('#calPrev').onclick = () => { calM--; if (calM < 0) { calM = 11; calY--; } renderCal(); };
$('#calNext').onclick = () => { calM++; if (calM > 11) { calM = 0; calY++; } renderCal(); };
$('#calToday').onclick = () => { selectDate(keyOf(new Date())); renderCal(); };
$('#calGrid').addEventListener('click', e => { const b = e.target.closest('[data-day]'); if (b && !b.disabled) { selectDate(b.dataset.day); renderCal(); } });

/* ---------- Collaborator picker (right-hand popup, closes only with Done) ---------- */
const picked = new Set();
function openPicker() {
  $('#picker').hidden = false; $('#app').classList.add('picking');
  renderPick();
  $('#pickList button')?.focus();
}
function closePicker() {
  if ($('#picker').hidden) return;
  $('#picker').hidden = true; $('#app').classList.remove('picking');
}
function renderPick() {
  if (!me || !user(me)) return;
  const ok = collabs();
  [...picked].forEach(n => { if (!ok.includes(n)) picked.delete(n); });   // only accepted collaborators can stay selected
  $('#pickCount').textContent = `${picked.size} selected`;
  $('#pickList').innerHTML = ok.map(n => `<button type="button" class="pick ${picked.has(n) ? 'on' : ''}" data-pick="${esc(n)}" aria-pressed="${picked.has(n)}">
      <div class="avatar">${initial(n)}</div><div class="info"><b>${esc(n)}</b><span class="line">${esc(user(n)?.info)}</span></div><span class="tick">✓</span></button>`).join('')
    || '<p class="dim">No collaborators yet. Send a request from Find a collaborator; it appears here once they accept.</p>';
}
function renderChips() {
  $('#mChips').innerHTML = [...picked].map(n => `<span class="chipx">${esc(n)}<button type="button" data-unpick="${esc(n)}" aria-label="Remove ${esc(n)}">&times;</button></span>`).join('');
  $('#openPick').textContent = picked.size ? `Edit collaborators (${picked.size})` : '+ Add collaborators';
}
$('#openPick').onclick = openPicker;
$('#pickDone').onclick = () => { closePicker(); $('#openPick').focus(); };
document.addEventListener('click', e => {
  const p = e.target.closest('[data-pick]'), u = e.target.closest('[data-unpick]');
  if (p) { const n = p.dataset.pick; picked.has(n) ? picked.delete(n) : picked.add(n); renderPick(); renderChips(); }
  if (u) { picked.delete(u.dataset.unpick); renderPick(); renderChips(); }
});

/* ---------- Meetings (create + edit) ---------- */
function renderMeet(fresh) {
  $('#meetHome').hidden = meetMode !== 'list'; $('#meetCreate').hidden = meetMode !== 'create';
  if (meetMode === 'list') { closePicker(); return renderMeetList(); }
  if (fresh && editMeet) {
    const m = db.meetings.find(x => x.id === editMeet);
    if (!m || m.owner !== me) { editMeet = null; meetMode = 'list'; return render(true); }
    selectDate(keyOf(new Date(m.ts))); $('#mTime').value = m.timeLabel; $('#mPurpose').value = m.purpose; $('#mLink').value = m.link;
    picked.clear(); m.members.filter(n => collabs().includes(n)).forEach(n => picked.add(n));
  } else if (fresh && meetProj) {                            // arrived via a project's "Add meeting"
    const p = db.projects.find(x => x.id === meetProj), now = new Date();
    selectDate(keyOf(now));
    $('#mTime').value = fmtTime(now); $('#mPurpose').value = p.name;
    $('#mLink').value = 'meet.collabspace/' + p.name.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + uid().slice(0, 4);
    picked.clear(); p.members.filter(n => collabs().includes(n)).forEach(n => picked.add(n));
  }
  $('#meetTitle').textContent = editMeet ? 'Edit meeting' : 'Create a meeting';
  $('#meetSave').textContent = editMeet ? 'Save changes' : 'Save';
  $('#meetNote').textContent = editMeet ? 'Everyone in this meeting gets a mail listing what changed.' : meetProj ? 'Project meeting: invites are sent automatically to every member of the project when you save.' : '';
  renderCal(); renderChips(); renderPick(); renderMeetList();
}
function renderMeetList() {
  const now = Date.now(), mine = db.meetings.filter(m => m.accepted.includes(me));
  const list = [...mine.filter(m => m.ts >= now).sort((a, b) => a.ts - b.ts), ...mine.filter(m => m.ts < now).sort((a, b) => b.ts - a.ts)];
  $('#meetList').innerHTML = list.map(m => { const d = new Date(m.ts), past = m.ts < now;
    return `<div class="meet ${past ? 'past' : ''}"><span class="t">${fmtDate(d)}<br>${esc(m.timeLabel)}</span>
      <span class="mi"><b>${esc(m.purpose)}</b><small>${esc(m.link)} &nbsp;·&nbsp; with ${esc(m.members.join(', ') || 'just you')}</small></span>
      <span class="macts">${!past && m.owner === me ? `<button class="ghost sm" data-medit="${m.id}">Edit</button>` : ''}${past ? '<span class="tag">Done</span>' : `<button class="btn" data-join="${m.id}">Join</button>`}</span></div>`; }).join('')
    || '<p class="dim">No meetings scheduled yet. Press Create to plan one.</p>';
}
$('#meetNew').onclick = () => { editMeet = null; meetMode = 'create'; render(true); };
$('#meetBack').onclick = () => { meetMode = 'list'; meetProj = null; editMeet = null; render(true); };
document.addEventListener('click', e => { const b = e.target.closest('[data-medit]'); if (b) { editMeet = b.dataset.medit; meetProj = null; meetMode = 'create'; render(true); } });

$('#meetForm').onsubmit = e => {
  e.preventDefault();
  const t = parseTime($('#mTime').value), msg = $('#meetMsg');
  if (!t) { msg.className = 'msg'; msg.textContent = 'Write the time like 4.00 pm'; return; }
  const d0 = fromKey(calSel), ts = new Date(d0.getFullYear(), d0.getMonth(), d0.getDate(), t[0], t[1]).getTime();
  if (ts <= Date.now()) { msg.className = 'msg'; msg.textContent = 'Pick a time in the future.'; return; }
  const link = $('#mLink').value.trim(), purpose = $('#mPurpose').value.trim(), timeLabel = fmtTime(new Date(ts));
  const send = (n, o) => db.mail.push({ id:uid(), from:me, to:n, status:'pending', ts:Date.now(), ...o });
  if (editMeet) {
    db = load(); const mt = db.meetings.find(x => x.id === editMeet);
    if (!mt || mt.owner !== me) { editMeet = null; meetMode = 'list'; return render(true); }
    const members = [...picked].filter(n => collabs().includes(n)), ch = [];
    if (mt.ts !== ts) ch.push(`When: ${fmtDate(new Date(mt.ts))}, ${mt.timeLabel} → ${fmtDate(new Date(ts))}, ${timeLabel}`);
    if (mt.purpose !== purpose) ch.push(`Purpose: ${mt.purpose} → ${purpose}`);
    if (mt.link !== link) ch.push(`Link: ${mt.link} → ${link}`);
    const added = members.filter(n => !mt.members.includes(n)), removed = mt.members.filter(n => !members.includes(n)), kept = mt.members.filter(n => members.includes(n));
    if (added.length) ch.push('Added: ' + added.join(', '));
    if (removed.length) ch.push('Removed: ' + removed.join(', '));
    Object.assign(mt, { purpose, ts, timeLabel, link, members });
    mt.accepted = mt.accepted.filter(n => n === me || members.includes(n));
    let sent = 0;
    if (ch.length) {
      kept.forEach(n => send(n, { type:'update', ref:mt.id, title:purpose, changes:ch }));
      removed.forEach(n => send(n, { type:'update', ref:mt.id, title:purpose, changes:['You were removed from this meeting.'] }));
      sent = kept.length + removed.length;
    }
    added.forEach(n => send(n, { type:'meeting', ref:mt.id }));
    toast(ch.length ? `Meeting updated, ${sent} change mail${sent === 1 ? '' : 's'} sent` : 'Nothing changed');
  } else {
    const pm = meetProj ? (db.projects.find(x => x.id === meetProj)?.members || []).filter(n => n !== me && user(n)) : [];
    const members = [...new Set([...picked].filter(n => collabs().includes(n)).concat(pm))];
    const mt = { id:uid(), owner:me, purpose, ts, timeLabel, link, members, accepted:[me] };
    db.meetings.push(mt); members.forEach(n => send(n, { type:'meeting', ref:mt.id }));
    if (meetProj) (db.chats['p:' + meetProj] ||= []).push({ from:me, ts:Date.now(), text:`Meeting "${purpose}" on ${fmtDate(new Date(ts))} at ${timeLabel} — ${link}` });
    toast(`Meeting saved — ${members.length} invite${members.length === 1 ? '' : 's'} sent`);
  }
  save(); e.target.reset(); picked.clear(); selectDate(keyOf(new Date())); closePicker();
  meetMode = 'list'; meetProj = null; editMeet = null; render(true);
};

/* ---------- Projects ---------- */
const isOwner = p => (p.owner || p.members[0]) === me;
const projInvited = (pid, n) => db.mail.some(m => m.type === 'project' && m.ref === pid && m.to === n && m.status === 'pending');
const inviteToProject = (p, n) => { const u = uidOf(n); if (u && !(p.invitedUids ||= []).includes(u)) p.invitedUids.push(u); db.mail.push({ id:uid(), type:'project', from:me, to:n, ref:p.id, status:'pending', ts:Date.now() }); };
function dropProject(id) { db.projects = db.projects.filter(x => x.id !== id); delete db.chats['p:' + id]; db.mail = db.mail.filter(m => !(m.type === 'project' && m.ref === id)); }

function renderProj(fresh) {
  if (openProj && !db.projects.find(x => x.id === openProj)) openProj = null;
  fillChecks('pCollabs');
  const mine = db.projects.filter(p => p.members.includes(me));
  $('#projHome').hidden = !!openProj; $('#projOpen').hidden = !openProj;
  $('#projList').innerHTML = mine.map(p => `<div class="card click" data-proj="${p.id}"><b>${esc(p.name)}</b><span class="line">${esc(p.purpose)}</span><span class="line">${p.members.length} member${p.members.length > 1 ? 's' : ''}</span></div>`).join('') || '<p class="dim">No projects yet.</p>';
  if (openProj) {
    const p = db.projects.find(x => x.id === openProj);
    $('#projName').textContent = p.name; $('#projPurpose').textContent = p.purpose;
    $('#projDel').hidden = !isOwner(p);
    $('#projMembers').innerHTML = p.members.map(n => `<div class="card"><div class="avatar">${initial(n)}</div><div class="info"><b>${esc(n)}</b><span class="line">${esc(user(n)?.info)}</span></div></div>`).join('');
    renderProjAdd(p);
    drawChat($('#projChat'), 'p:' + p.id, p.name + ' · group chat');
  }
}
/* ---------- Project: invite collaborators to an open project ---------- */
let projAddOpen = false;
function renderProjAdd(p) {
  $('#projAddBox').hidden = !projAddOpen; $('#projAdd').textContent = projAddOpen ? 'Done' : '+ Invite collaborators';
  if (!projAddOpen) return;
  const cand = collabs().filter(n => isMutual(n) && !p.members.includes(n));
  $('#projAddBox').innerHTML = cand.map(n => { const inv = projInvited(p.id, n);
    return `<button type="button" class="pick add" data-padd="${esc(n)}" ${inv ? 'disabled' : ''}><div class="avatar">${initial(n)}</div><div class="info"><b>${esc(n)}</b><span class="line">${inv ? 'Invite sent, waiting' : esc(user(n)?.info)}</span></div><span class="tick">${inv ? '…' : '+'}</span></button>`; }).join('')
    || '<p class="dim">Every mutual collaborator is already in this project.</p>';
}
$('#projAdd').onclick = () => { projAddOpen = !projAddOpen; render(); };
document.addEventListener('click', e => {
  const a = e.target.closest('[data-padd]'); if (!a) return;
  const p = db.projects.find(x => x.id === openProj), n = a.dataset.padd;
  if (!p || !isMutual(n) || p.members.includes(n) || projInvited(p.id, n)) return;
  inviteToProject(p, n); save(); toast(`Invite sent to ${n}`); render();
});

$('#projForm').onsubmit = e => {
  e.preventDefault();
  const p = { id:uid(), owner:me, name:$('#pName').value.trim(), purpose:$('#pPurpose').value.trim(), members:[me] };
  db.projects.push(p); db.chats['p:' + p.id] = [{ from:'system', ts:Date.now(), text:`Group chat created for ${p.name}.` }];
  const inv = checked('pCollabs').filter(isMutual); inv.forEach(n => inviteToProject(p, n));
  save(); e.target.reset(); toast(inv.length ? `Project created, ${inv.length} invite${inv.length === 1 ? '' : 's'} sent` : 'Project created'); render();
};
document.addEventListener('click', e => {
  const c = e.target.closest('[data-proj]'); if (c) { openProj = c.dataset.proj; projAddOpen = false; render(); }
});
$('#projBack').onclick = () => { openProj = null; projAddOpen = false; render(); };
$('#projMeet').onclick = () => { meetProj = openProj; editMeet = null; meetMode = 'create'; setView('meet'); };
$('#projExit').onclick = async () => {
  const p0 = db.projects.find(x => x.id === openProj); if (!p0) return;
  if (!(await askSkey(`Enter your SKEY to exit “${p0.name}”.`))) return;
  db = load(); const p = db.projects.find(x => x.id === openProj); if (!p) return;
  p.members = p.members.filter(n => n !== me);
  if (!p.members.length) dropProject(p.id);
  else { if (p.owner === me || !p.owner) p.owner = p.members[0]; (db.chats['p:' + p.id] ||= []).push({ from:'system', ts:Date.now(), text:`${me} left the project.` }); }
  save(); openProj = null; projAddOpen = false; toast('You left the project'); render();
};
$('#projDel').onclick = async () => {
  const p0 = db.projects.find(x => x.id === openProj); if (!p0 || !isOwner(p0)) return;
  if (!(await askSkey(`Enter your SKEY to delete “${p0.name}” for everyone.`))) return;
  db = load(); dropProject(openProj); save(); openProj = null; projAddOpen = false; toast('Project deleted'); render();
};

/* ---------- Collaborators: every user is listed ---------- */
function renderCollab() {
  const others = Object.keys(db.users).filter(n => n !== me);
  $('#collabList').innerHTML = others.map(n => {
    const isC = collabs().includes(n), sent = inviteSent(n), got = inviteReceived(n);
    const action = isC ? `<button class="msgbtn" data-dm="${esc(n)}">Message</button>`
      : got ? `<span class="dim">Request received — see Mail</span>`
      : `<button class="btn" data-invite="${esc(n)}" ${sent ? 'disabled' : ''}>${sent ? 'Invited' : 'Invite'}</button>`;
    return `<div class="card"><div class="avatar">${initial(n)}</div>
      <div class="info"><b>${esc(n)}</b><span class="line">${esc(user(n).info)}</span></div>${action}</div>`;
  }).join('') || '<p class="dim">No other users yet. Open another tab and sign in with a different Google account.</p>';
}
document.addEventListener('click', e => { const b = e.target.closest('[data-dm]'); if (b && isMutual(b.dataset.dm)) { openChat = dmKey(me, b.dataset.dm); setView('chat'); } });

/* ---------- Chat — WhatsApp Web style: mutuals + project groups on the left, conversation on the right ---------- */
const canChat = key => key.startsWith('p:') || isMutual(key.split('|').find(n => n !== me));
function chatName(key) {
  if (key.startsWith('p:')) return db.projects.find(p => p.id === key.slice(2))?.name + ' (group)';
  return key.split('|').find(n => n !== me);
}
const lastMsg = k => db.chats[k]?.at(-1);
const stamp = ts => keyOf(new Date(ts)) === keyOf(new Date()) ? fmtTime(new Date(ts)) : new Date(ts).toLocaleDateString(undefined, { day:'numeric', month:'short' });
const unread = k => { const r = user(me).read?.[k] || 0; return (db.chats[k] || []).filter(m => m.from !== me && m.from !== 'system' && m.ts > r).length; };
function markRead(k) { if (unread(k)) { (user(me).read ||= {})[k] = Date.now(); save(); } }
function chatKeys() {                                         // every mutual + every group I'm in, newest activity first
  const groups = db.projects.filter(p => p.members.includes(me)).map(p => 'p:' + p.id);
  const dms = collabs().filter(isMutual).map(n => dmKey(me, n)), last = k => lastMsg(k)?.ts || 0;
  return [...groups, ...dms].sort((a, b) => last(b) - last(a) || chatName(a).localeCompare(chatName(b)));
}
const recentKeys = () => chatKeys().filter(k => lastMsg(k));

function chatRow(k, attr, on) {
  const m = lastMsg(k), u = unread(k), g = k.startsWith('p:'), who = chatName(k).replace(/ \(group\)$/, '');
  const pre = !m ? '' : m.from === me ? 'You: ' : g && m.from !== 'system' ? m.from + ': ' : '';
  const sub = m ? pre + m.text : g ? 'Group chat' : user(who)?.info;
  return `<button type="button" class="crow ${on ? 'on' : ''}" ${attr}="${esc(k)}"><div class="avatar ${g ? 'grp' : ''}">${initial(who)}</div>
    <div class="cmid"><div class="ctop"><b>${esc(who)}</b>${m ? `<time class="${u ? 'new' : ''}">${stamp(m.ts)}</time>` : ''}</div>
    <div class="cbot"><span class="line">${esc(sub)}</span>${u ? `<i class="ub">${u}</i>` : ''}</div></div></button>`;
}
const EMPTY = '<div class="wempty"><svg viewBox="0 0 24 24"><use href="#i-chat"/></svg><h3>Collabspace Chat</h3><p class="dim">Pick a collaborator on the left to start chatting.<br>Only mutual collaborators can message each other.</p></div>';

function renderChatList() {
  const q = $('#chatSearch').value.trim().toLowerCase(), all = chatKeys();
  $('#chatCollabs').innerHTML = all.filter(k => chatName(k).toLowerCase().includes(q)).map(k => chatRow(k, 'data-chat', k === openChat)).join('')
    || `<p class="dim pad">${all.length ? 'No matches.' : 'No mutual collaborators yet. Send a request from Find a collaborator; chat opens once they accept.'}</p>`;
}
function renderChat() {
  if (openChat && !chatKeys().includes(openChat)) openChat = null;
  if (openChat) markRead(openChat);
  renderChatList();
  $('#wa').classList.toggle('open', !!openChat);
  if (openChat) drawChat($('#chatMain'), openChat, chatName(openChat)); else $('#chatMain').innerHTML = EMPTY;
}
$('#chatSearch').oninput = renderChatList;
document.addEventListener('click', e => {
  const c = e.target.closest('[data-chat]'); if (c) { openChat = c.dataset.chat; focusNext = true; renderChat(); badges(); }
  if (e.target.closest('[data-waback]')) { openChat = null; renderChat(); }
});
function badges() {
  const n = chatKeys().reduce((a, k) => a + unread(k), 0);
  $('#chatCount').hidden = !n; $('#chatCount').textContent = n;
}

function drawChat(el, key, title) {
  markRead(key);
  const msgs = db.chats[key] || [], allowed = canChat(key), grp = key.startsWith('p:'), name = title.replace(/ \(group\)$/, '');
  const draft = el.querySelector('.send input')?.value || '', today = keyOf(new Date());
  const sub = grp ? (db.projects.find(p => p.id === key.slice(2))?.members.join(', ') || '') : (user(key.split('|').find(n => n !== me))?.info || '');
  let day = '';
  const rows = msgs.map(m => {
    const d = new Date(m.ts), k = keyOf(d); let sep = '';
    if (k !== day) { day = k; sep = `<div class="dsep"><span>${k === today ? 'Today' : fmtDate(d)}</span></div>`; }
    if (m.from === 'system') return sep + `<div class="sys"><span>${esc(m.text)}</span></div>`;
    return sep + `<div class="bub ${m.from === me ? 'me' : ''}">${grp && m.from !== me ? `<em>${esc(m.from)}</em>` : ''}<span>${esc(m.text)}</span><time>${fmtTime(d)}${m.from === me ? ' <i>✓✓</i>' : ''}</time></div>`;
  }).join('');
  el.innerHTML = `<div class="chead">${view === 'chat' ? '<button type="button" class="waback" data-waback aria-label="Back to chats">&lsaquo;</button>' : ''}<div class="avatar ${grp ? 'grp' : ''}">${initial(name)}</div><div class="cmid"><b>${esc(name)}</b><span class="line">${esc(sub)}</span></div></div>
    <div class="msgs">${rows}</div>`
    + (allowed ? `<form class="send"><input placeholder="Type a message" required autocomplete="off"><button class="sendbtn" aria-label="Send"><svg viewBox="0 0 24 24"><path d="M4 12l16-8-6 16-3-7z"/></svg></button></form>`
      : `<p class="dim locknote">You can chat only after both of you have accepted each other’s request.</p>`);
  const box = el.querySelector('.msgs'); box.scrollTop = box.scrollHeight;
  const form = el.querySelector('form'); if (!form) return;
  const inp = form.querySelector('input'); inp.value = draft; if (focusNext) { inp.focus(); focusNext = false; }
  form.onsubmit = e => {
    e.preventDefault(); const t = inp.value.trim(); if (!t || !canChat(key)) return;
    (db.chats[key] ||= []).push({ from:me, ts:Date.now(), text:t }); inp.value = ''; save(); focusNext = true; render();
  };
}

/* ---------- Portfolio ---------- */
function renderPort(fresh) {
  if (!fresh) return; const u = user(me);
  $('#poInfo').value = u.info; $('#poSkills').value = u.skills; $('#poAbout').value = u.about; $('#poLinks').value = u.links;
}
$('#portForm').onsubmit = e => {
  e.preventDefault(); const u = user(me);
  Object.assign(u, { info:$('#poInfo').value.trim() || u.info, skills:$('#poSkills').value, about:$('#poAbout').value, links:$('#poLinks').value });
  save(); $('#portMsg').className = 'msg ok'; $('#portMsg').textContent = 'Portfolio saved.';
};

/* ---------- Settings: change SKEY by typing your Gmail ---------- */
function renderSettings(fresh) {
  if (!fresh) return;
  $('#stName').value = me; $('#stEmail').value = secret?.email || gUser?.email || ''; $('#stMsg').textContent = '';
}
$('#skeyChange').onsubmit = async e => {
  e.preventDefault(); const msg = $('#stMsg'); msg.className = 'msg';
  const a = $('#stNew').value;
  if (!secret || $('#stConfirm').value.trim().toLowerCase() !== secret.email) { msg.textContent = 'That is not the Gmail you signed in with.'; return; }
  if (!isKey(a)) { msg.textContent = 'SKEY must be exactly 4 digits.'; return; }
  if (a !== $('#stNew2').value) { msg.textContent = 'The two SKEYs do not match.'; return; }
  const next = { ...secret, skey: await hashKey(a, secret.email) };
  try { await window.cwStore.setSecret(gUser.uid, next); secret = next; } catch (err) { msg.textContent = 'Could not update the SKEY (' + (err.code || err.message) + ').'; return; }
  e.target.reset(); msg.className = 'msg ok'; msg.textContent = 'SKEY updated.';
};

/* ---------- Neural network on Home (fills the free space under the clock; click it to fire a signal wave) ---------- */
(function neural() {
  const cv = $('#neural'), ctx = cv.getContext('2d'), L = [3, 5, 6, 5, 3];
  const still = matchMedia('(prefers-reduced-motion:reduce)').matches;
  let w = 0, h = 0, dpr = 1, N = [], E = [], out = [], P = [], lastSpawn = 0;

  function layout() {
    dpr = window.devicePixelRatio || 1; w = cv.clientWidth; h = cv.clientHeight; cv.width = w * dpr; cv.height = h * dpr;
    N = []; E = []; P = []; if (!w || !h) return;
    const vert = h >= w, pad = 24, idx = [];                 // tall box: layers run top to bottom, wide box: left to right
    L.forEach((n, li) => { idx.push([]); for (let i = 0; i < n; i++) {
      const a = (li + .5) / L.length, b = (i + .5) / n;
      N.push({ li, bx: pad + (vert ? b : a) * (w - 2 * pad), by: pad + (vert ? a : b) * (h - 2 * pad), g: 0, ph: Math.random() * 6.28 });
      idx[li].push(N.length - 1); } });
    for (let li = 0; li < L.length - 1; li++) idx[li].forEach(a => idx[li + 1].forEach(b => E.push({ a, b, li, w: Math.random() })));
    out = N.map(() => []); E.forEach(e => out[e.a].push(e));
  }
  const fire = e => { if (P.length < 70) P.push({ e, t: 0, v: .011 + Math.random() * .01 }); };
  const wave = () => E.filter(e => e.li === 0).forEach(fire);

  function step(ts) {
    if (ts - lastSpawn > 420) { lastSpawn = ts; const f = E.filter(e => e.li === 0); if (f.length) fire(f[Math.random() * f.length | 0]); }
    P = P.filter(p => {
      p.t += p.v; if (p.t < 1) return true;
      const n = N[p.e.b]; n.g = 1;                           // signal arrives: node lights up, then feeds the next layer
      const nx = out[p.e.b]; nx.forEach(e => { if (Math.random() < .55) fire(e); });
      return false;
    });
  }
  function draw(ts) {
    const t = ts / 1000; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
    N.forEach(n => { n.x = n.bx + Math.sin(t * .8 + n.ph) * 3; n.y = n.by + Math.cos(t * .7 + n.ph) * 3; });
    E.forEach(e => { const A = N[e.a], B = N[e.b]; ctx.strokeStyle = `rgba(139,156,255,${.06 + .13 * e.w})`; ctx.lineWidth = .5 + e.w * .9; ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y); ctx.stroke(); });
    P.forEach(p => {
      const A = N[p.e.a], B = N[p.e.b], x = A.x + (B.x - A.x) * p.t, y = A.y + (B.y - A.y) * p.t, g = ctx.createRadialGradient(x, y, 0, x, y, 10);
      g.addColorStop(0, 'rgba(111,227,212,.95)'); g.addColorStop(1, 'rgba(111,227,212,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 10, 0, 7); ctx.fill();
    });
    N.forEach(n => {
      ctx.shadowBlur = 12 * n.g; ctx.shadowColor = 'rgba(111,227,212,.95)';
      ctx.fillStyle = `hsla(${235 - 65 * n.li / (L.length - 1)},90%,${68 + 20 * n.g}%,${.55 + .45 * n.g})`;
      ctx.beginPath(); ctx.arc(n.x, n.y, 3.2 + 2.6 * n.g, 0, 7); ctx.fill(); ctx.shadowBlur = 0; n.g *= .93;
    });
  }
  new ResizeObserver(() => { layout(); if (still) draw(0); }).observe(cv);
  cv.addEventListener('pointerdown', wave);
  (function frame(ts) {
    requestAnimationFrame(frame);
    if (still || !w || view !== 'home' || $('#app').hidden) return;
    step(ts); draw(ts);
  })(0);
})();

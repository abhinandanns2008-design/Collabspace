// Firebase: Google sign-in (Auth) + shared data (Firestore) for project "collabspace-be7c3".
// script.js defines window.cwOnUser (sign-in state) and window.cwApplyRemote (Firestore snapshots);
// this file exposes window.cwAuth and window.cwStore for it.
import { initializeApp } from "https://www.gstatic.com/firebasejs/13.3.0/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged }
  from "https://www.gstatic.com/firebasejs/13.3.0/firebase-auth.js";
import { getFirestore, collection, doc, getDoc, setDoc, query, where, onSnapshot, writeBatch, arrayUnion }
  from "https://www.gstatic.com/firebasejs/13.3.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBMi04lQNvSuYCB7SjV1EGqNSrblNiYe9o",
  authDomain: "collabspace-be7c3.firebaseapp.com",
  projectId: "collabspace-be7c3",
  storageBucket: "collabspace-be7c3.firebasestorage.app",
  messagingSenderId: "840862093237",
  appId: "1:840862093237:web:bc77aa32a711412d69d3fc"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const fs = getFirestore(app);
const provider = new GoogleAuthProvider();
provider.setCustomParameters({ prompt: "select_account" });

window.cwAuth = {
  signIn: () => signInWithPopup(auth, provider),
  signOut: () => signOut(auth)
};
onAuthStateChanged(auth, u => window.cwOnUser && window.cwOnUser(u));

window.cwStore = {
  // Private per-user document (Gmail + hashed SKEY). Only its owner can read it.
  getSecret: async uid => { const s = await getDoc(doc(fs, "secrets", uid)); return s.exists() ? s.data() : null; },
  setSecret: (uid, data) => setDoc(doc(fs, "secrets", uid), data),

  // Live listeners. Every query is filtered so it satisfies firestore.rules.
  // cb(source, docs, fromLocalWrite) runs for every snapshot; ready resolves after the first one of each.
  watch(uid, cb) {
    const sources = {
      users:       collection(fs, "users"),
      projects:    collection(fs, "projects"),
      "mail:to":   query(collection(fs, "mail"), where("toUid", "==", uid)),
      "mail:from": query(collection(fs, "mail"), where("fromUid", "==", uid)),
      meetings:    query(collection(fs, "meetings"), where("memberUids", "array-contains", uid)),
      chats:       query(collection(fs, "chats"), where("uids", "array-contains", uid))
    };
    const unsubs = [];
    const ready = Promise.all(Object.entries(sources).map(([name, q]) => new Promise((res, rej) => {
      let first = true;
      unsubs.push(onSnapshot(q, snap => {
        cb(name, snap.docs.map(d => ({ id: d.id, data: d.data() })), snap.metadata.hasPendingWrites);
        if (first) { first = false; res(); }
      }, err => { if (first) { first = false; rej(err); } else console.error(name, err); }));
    })));
    return { ready, stop: () => unsubs.forEach(u => u()) };
  },

  // ops: {t:'set',col,id,data} | {t:'del',col,id} | {t:'chat',id,data,add:[messages]} (messages are appended, never overwritten)
  async commit(ops) {
    for (let i = 0; i < ops.length; i += 400) {
      const b = writeBatch(fs);
      ops.slice(i, i + 400).forEach(o => {
        if (o.t === "set") b.set(doc(fs, o.col, o.id), o.data);
        else if (o.t === "del") b.delete(doc(fs, o.col, o.id));
        else b.set(doc(fs, "chats", o.id), o.add.length ? { ...o.data, msgs: arrayUnion(...o.add) } : o.data, { merge: true });
      });
      await b.commit();
    }
  }
};
